# 🎂 Interactive Birthday Website

Everything is free and works as a static website.

## Customize

Open `index.html` and find:

    const CONFIG = {
      name: "Bestie",
      message: `...`
    };

Change the name and message.

## Add photos

Put three images in this same folder and name them:

- photo1.jpg
- photo2.jpg
- photo3.jpg

They will automatically appear in the memory section.

## Run locally

Double-click `index.html` to open it in a browser.

## Put it online for free with GitHub Pages

1. Create a free GitHub account.
2. Create a new public repository, e.g. `birthday-website`.
3. Upload `index.html`, `photo1.jpg`, `photo2.jpg`, and `photo3.jpg`.
4. Open repository Settings → Pages.
5. Select "Deploy from a branch".
6. Select `main` and `/ (root)`.
7. Save.
8. GitHub will give you a free `github.io` website link.

No paid hosting or domain is required.
